import sqlite3
import csv

try:
    # Connect to SQLite database
    conn = sqlite3.connect('Data Engineer_ETL Assignment.db')

    # Create a cursor object to execute SQL queries
    cur = conn.cursor()

    # Execute the SQL query to fetch data from the Database
    cur.execute('''SELECT c.customer_id as Customer, c.age as Age, i.item_name As Item, SUM(o.quantity) AS Quantities
    FROM Customers c
    JOIN Sales s ON c.customer_id = s.customer_id
    JOIN Orders o ON s.sales_id = o.sales_id
    JOIN Items i ON o.item_id = i.item_id
    WHERE c.age BETWEEN 18 AND 35
    GROUP BY c.customer_id, i.item_id
    HAVING Quantities > 0;''')

    # Fetch all rows from the query result
    result = cur.fetchall()

    # Define the output CSV file
    csv_file = "output.csv"

    # Open the CSV file in write mode with newline='' to prevent extra newline characters
    with open(csv_file, 'w', newline='') as f:
        # Create a CSV writer object with ';' as delimiter
        writer = csv.writer(f, delimiter=';')

        # Write the column names as the header row for desired result
        writer.writerow(['Customer', 'Age', 'Item', 'Quantity'])

        # Write the fetched data rows
        writer.writerows(result)

    # Close the cursor
    cur.close()

    # Commit the transaction and close the connection
    conn.commit()
    conn.close()

    print("Data successfully written to", csv_file)

except sqlite3.Error as e:
    # Handle SQLite errors
    print("SQLite error:", e)

except csv.Error as e:
    # Handle CSV-related errors
    print("CSV error:", e)

except IOError as e:
    # Handle file I/O errors
    print("I/O error:", e)

except Exception as e:
    # Handle any other unexpected errors
    print("An unexpected error occurred:", e)