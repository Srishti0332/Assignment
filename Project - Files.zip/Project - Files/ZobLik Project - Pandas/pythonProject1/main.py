import sqlite3
import pandas as pd

try:
    # Connection to SQLite Database
    conn = sqlite3.connect('Data Engineer_ETL Assignment.db')

    # Define the name of the CSV output file
    csv_file = "output.csv"

    # Read data from the 'Customers', 'Sales', 'Orders', and 'Items' tables into different DataFrames
    customers_df = pd.read_sql_query("SELECT * FROM Customers", conn)
    sales_df = pd.read_sql_query("SELECT * FROM Sales", conn)
    orders_df = pd.read_sql_query("SELECT * FROM Orders", conn)
    items_df = pd.read_sql_query("SELECT * FROM Items", conn)

    # Drop rows containing NULL values in the 'Orders' DataFrame as it is not required in final answer
    orders_df = orders_df.dropna()

    # Check if there are NULL values in the 'Orders' DataFrame - Error Handling
    if orders_df.isnull().values.any():
        raise ValueError("NaN values found in 'Orders' DataFrame")

    # Round the 'quantity' column to remove the decimal part and convert it to integer type as Decimal is not required in final answer
    orders_df['quantity'] = orders_df['quantity'].round().astype(int)

    # Combine DataFrames using JOIN operations to create a single DataFrame - Join Operation
    super_df = customers_df.merge(sales_df, on='customer_id') \
                               .merge(orders_df, on='sales_id') \
                               .merge(items_df, on='item_id')

    # Filter rows based on WHERE clause condition (age between 18 and 35) - Filtering results based on 'where' clause
    filter_df = super_df[(super_df['age'] >= 18) & (super_df['age'] <= 35)]

    # Group by 'customer_id', 'item_id', and 'item_name', then aggregate 'quantity' using the SUM function - Grouping results as per the format
    group_df = filter_df.groupby(['customer_id', 'item_id', 'item_name'])['quantity'].sum().reset_index()

    # Apply HAVING condition to filter out rows where 'quantity' > 0
    result_df = group_df[group_df['quantity'] > 0]

    # Rename columns for readability
    result_df.columns = ['Customer', 'Age', 'Item', 'Quantity']

    # Write the grouped DataFrame to a CSV file with semicolon as delimiter
    result_df.to_csv(csv_file, sep=';', index=False)

    print("Data has been successfully written to", csv_file)

except sqlite3.Error as e:  # handling Exception
    print("SQLite error:", str(e))

except pd.errors.EmptyDataError as e:
    print("Empty data error:", str(e))

except ValueError as e:
    print("Value error:", str(e))

except Exception as e:
    print("An unexpected error occurred:", str(e))

finally:
    # Close the connection to the SQLite database
    if conn:
        conn.close()